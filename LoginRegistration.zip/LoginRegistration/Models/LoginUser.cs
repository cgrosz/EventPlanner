using System.ComponentModel.DataAnnotations;

namespace LoginRegistration.Models
{
    public class LogInUser
    {
        [Required]
        [Display(Name="Email: ")]
        [EmailAddress]
        public string LogInEmail {get; set;}
        [Required]
        [Display(Name="Password: ")]
        [DataType(DataType.Password)]
        public string LogInPassword {get; set;}
    }
}